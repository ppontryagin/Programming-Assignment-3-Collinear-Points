/**
 * Created by Pavel.Pontryagin on 13.03.2015.
 */
public class Fast {
    public static void main(String[] args) {

    }

}
